#include "flower.h"
#include "grassmanager.h"

Flower::Flower() : PowerUp("Flower", 10) {}
void Flower::activate() { GrassManager::addPassiveIncome(5); }
std::shared_ptr<PowerUp> Flower::clone() const { return std::make_shared<Flower>(*this); }
